<?php
/*
Plugin Name: Insert HTML After Paragraphs
Description: A plugin to insert custom HTML code after a specified number of paragraphs.
Version: 1.0
Author: Your Name
*/

// Function to insert HTML after a specified number of paragraphs
function insert_html_after_paragraphs($content) {
    if (is_single()) {
        $html_code = get_option('insert_html_code'); // Retrieve the HTML code from the plugin settings
        $paragraphs = explode('</p>', $content);
        $new_content = '';

        foreach ($paragraphs as $index => $paragraph) {
            $new_content .= $paragraph;
            if ($index == 4) { // Insert after the 5th paragraph (index starts at 0)
                $new_content .= $html_code;
            }
            $new_content .= '</p>';
        }
        return $new_content;
    }
    return $content;
}
add_filter('the_content', 'insert_html_after_paragraphs');

// Function to create the settings menu and page
function insert_html_menu() {
    add_options_page(
        'Insert HTML Settings', 
        'Insert HTML', 
        'manage_options', 
        'insert-html-settings', 
        'insert_html_settings_page'
    );
}
add_action('admin_menu', 'insert_html_menu');

// Function to display the settings page
function insert_html_settings_page() {
    ?>
    <div class="wrap">
        <h1>Insert HTML Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('insert_html_settings_group');
            do_settings_sections('insert-html-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Function to register settings and add fields to the settings page
function insert_html_register_settings() {
    register_setting('insert_html_settings_group', 'insert_html_code');

    add_settings_section(
        'insert_html_main_section', 
        'Main Settings', 
        'insert_html_main_section_callback', 
        'insert-html-settings'
    );

    add_settings_field(
        'insert_html_code_field', 
        'HTML Code', 
        'insert_html_code_field_callback', 
        'insert-html-settings', 
        'insert_html_main_section'
    );
}
add_action('admin_init', 'insert_html_register_settings');

// Callback function for the main settings section
function insert_html_main_section_callback() {
    echo 'Enter the HTML code you want to insert after the specified number of paragraphs.';
}

// Callback function for the HTML code field
function insert_html_code_field_callback() {
    $html_code = get_option('insert_html_code');
    echo '<textarea name="insert_html_code" rows="10" cols="50" class="large-text">' . esc_textarea($html_code) . '</textarea>';
}
?>
